class Constants:
    
    base_fare = 5
    
    file_name = "_Flight_Ticket.pdf"
    
    
    